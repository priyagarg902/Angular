export interface IRoom{
    RoomNo:number;
    RoomType: string;
    MaxRoomCapacity:number;
    MinimumRate:number;
    MaximumRate:number;
}