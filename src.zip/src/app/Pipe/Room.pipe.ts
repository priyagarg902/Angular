import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name:'filter'
})
export class RoomPipe implements PipeTransform{
    transform(details: any[], RoomType:string):any[] {
        if(!details){
            return [];
        }
        if(!RoomType){
            return;
        }
        return details.filter(dt=>{ return dt.RoomType==RoomType;})
    }
    
}