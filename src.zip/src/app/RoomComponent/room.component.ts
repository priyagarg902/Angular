import { OnInit, Component } from '@angular/core';
import { RoomService } from '../Services/RoomService';
import { IRoom } from '../Entities/RoomEntities';

@Component({
    selector:"app-room",
    templateUrl:'room.component.html'
})
export class RoomComponent implements OnInit{
    details:IRoom[];
    submitted:boolean= false;
    ngOnInit(): void {

        this.getAll();
    }

    constructor(private roomservice:RoomService){

    }

    getAll(){
this.roomservice.getDetails().subscribe(data=>{
    this.details=data;
});
    }

    onSubmit(){
        this.submitted=true;
        this.roomservice.getDetails().subscribe(data=>{
            this.details=data;
        })
    }

    textRemove(){
        this.submitted=false;
    }

}