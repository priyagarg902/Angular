import { Injectable, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IRoom } from '../Entities/RoomEntities';

@Injectable()
export class RoomService implements OnInit{

    url:string="assets/data/Room.json";
    ngOnInit(): void {
       this.getDetails();
    }
    constructor(private _http:HttpClient){

    }

    getDetails(){

         return this._http.get<IRoom[]>(this.url);

    }

}