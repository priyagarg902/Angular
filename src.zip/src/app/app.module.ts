import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { HttpClientModule } from '@angular/common/http';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RoomComponent } from './RoomComponent/room.component';
import { RoomService } from './Services/RoomService';

import { RoomPipe } from './Pipe/Room.pipe';

@NgModule({
  declarations: [
    AppComponent,
    RoomComponent,
    RoomPipe
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [RoomService],
  bootstrap: [AppComponent]
})
export class AppModule { }
