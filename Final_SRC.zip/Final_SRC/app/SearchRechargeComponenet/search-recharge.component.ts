import { Component, OnInit } from '@angular/core';
import { RechargeService } from '../Services/RechargeService';
import {FormBuilder,FormGroup} from '@angular/forms';
import { IRecharge } from '../Models/MyRechargeModel';

@Component({
  selector: 'app-search-recharge',
  templateUrl: 'search-recharge.component.html',
  styleUrls: ['search-recharge.component.css']
})
export class SearchRechargeComponent implements OnInit {
  details:IRecharge[];
  submitted:Boolean=false;

  constructor(private recservice:RechargeService,private formBuilder:FormBuilder) { }

  ngOnInit() {
  }
  
  onSubmit(){
    this.submitted=true;
    this.recservice.getDetails().subscribe(data=>{
        this.details=data;
    }) 
   
  }
  txtchanged(){
    this.submitted=false;
  }
}
