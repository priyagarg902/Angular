import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {RechargeDisplayComponent} from './DisplayComponent/recharge-display.component';
import {SearchRechargeComponent} from './SearchRechargeComponenet/search-recharge.component';


const routes: Routes = [
  {path:'',component:RechargeDisplayComponent},
  {path:'getAll',component:RechargeDisplayComponent},
  {path:'getFilter',component:SearchRechargeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
