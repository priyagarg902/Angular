import {Injectable,OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {IRecharge} from '../Models/MyRechargeModel';

@Injectable()
export class RechargeService implements OnInit{

    url:string="/assets/RechargeData.json";
    ngOnInit(): void{
        this.getDetails();
    }
    constructor(private _http:HttpClient){

    }

    getDetails(){return this._http.get<IRecharge[]>(this.url);}
}