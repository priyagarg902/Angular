import {HttpClientModule} from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {RechargeService} from './Services/RechargeService';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {RechargeDisplayComponent} from './DisplayComponent/recharge-display.component';
import {SearchRechargeComponent} from './SearchRechargeComponenet/search-recharge.component';
import {RechargePipe} from './Pipe/Recharge.Pipe';

import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent,
    RechargeDisplayComponent,
    //SearchRechargeComponent,
    RechargePipe
  ],
  imports: [
    BrowserModule,
    //AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [RechargeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
