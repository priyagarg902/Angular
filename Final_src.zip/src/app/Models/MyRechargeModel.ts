export interface IRecharge{
    TranId:number;
    RechargeDateTime:Date;
    RechargeCategory:string;
    RechargeAmount:number;
    MobileNo:string;
    Details:string;
}