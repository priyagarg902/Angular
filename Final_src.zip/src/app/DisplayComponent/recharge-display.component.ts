import { Component, OnInit } from '@angular/core';
import { RechargeService } from '../Services/RechargeService';
import { IRecharge } from '../Models/MyRechargeModel';
import {FormBuilder,FormGroup} from '@angular/forms';

@Component({
  selector: 'app-recharge-display',
  templateUrl: 'recharge-display.component.html',
  styleUrls: ['./recharge-display.component.css']
})
export class RechargeDisplayComponent implements OnInit {
  details:IRecharge[];
  submitted:Boolean=false;
  
  constructor(private recservice:RechargeService,private formBuilder:FormBuilder) { }

  ngOnInit() {
    this.getAll();
  }
  getAll(){
    this.recservice.getDetails().subscribe(data=>{
        this.details=data;});

}

onSubmit(){
  this.submitted=true;
  this.recservice.getDetails().subscribe(data=>{
      this.details=data;
  
  }) 
 
}
txtchanged(){
  this.submitted=false;
}
}
